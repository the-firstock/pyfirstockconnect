NSE_FILE = "https://trade.thefirstock.com/NSE_Symbol.csv.zip"
BSE_FILE = "https://trade.thefirstock.com/BSE_Symbol.csv.zip"
BFO_FILE = "https://trade.thefirstock.com/BFO_Symbol.csv.zip"
NFO_FILE = "https://trade.thefirstock.com/NFO_Symbol.csv.zip"


NSE_FILE_CSV = "downloads/NSE_Symbol.csv"
BSE_FILE_CSV = "downloads/BSE_Symbol.csv"
BFO_FILE_CSV = "downloads/BFO_Symbol.csv"
NFO_FILE_CSV = "downloads/NFO_Symbol.csv"

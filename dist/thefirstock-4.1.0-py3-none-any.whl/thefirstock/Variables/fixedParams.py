"""
Parameters for FIRSTOCK API
"""

APKVERSION = '1.0.0'
IMEI = '123456'
SOURCE = 'API'


